/**
 * content.js —— 智能识别门户表单 + 自动登录（独立脚本，document_idle 注入）
 *
 * 适配思路：
 *   1) 优先用弹窗里手填的 CSS 选择器；
 *   2) 否则按 type / placeholder / name / id / class 关键词自动识别，
 *      覆盖 Vue / ElementUI / jQuery 等常见写法的校园网门户；
 *   3) 无论哪种，都在弹窗“测试识别”里给出结果，方便校准。
 */
(function () {
  'use strict';
  if (window.__WFU_CONTENT_LOADED__) return;
  window.__WFU_CONTENT_LOADED__ = true;

  // ============ 默认配置（与 shared.js 保持一致） ============
  var DEFAULTS = {
    enabled: true,
    username: '',
    password: '',
    portalUrl: 'http://210.44.64.60/gportal/web/login',
    portalOrigin: 'http://210.44.64.60',
    autoLogin: true,
    maxRetry: 3,
    selectorUser: '',
    selectorPass: '',
    selectorSubmit: ''
  };

  var LOGIN_HINT = /学工号|工号|学号|用户名|账号|帐号|用户|username|user|account|login|name|zhanghao|yonghu|xuehao|student/i;
  var PASS_HINT = /密码|password|passwd|pwd|mima/i;
  var SUBMIT_TEXT = /登\s*录|登\s*入|登\s*陆|连\s*接|上\s*网|认\s*证|login|sign\s*in|signin|submit|确定|确认/i;
  var FAIL_TEXT = /密码错误|用户名或密码|账号或密码|账号不存在|用户不存在|认证失败|登录失败|错误|失败|无效|未开通|已停用|欠费|不在线时间/i;
  var ONLINE_TEXT = /在线时长|已在线|当前在线|下线|注销|退出登录|剩余时长/i;
  var LOGIN_PAGE_TEXT = /使用须知|请输入学工号|请输入密码|忘记|设置密码|欢迎使用/i;

  var cfg = Object.assign({}, DEFAULTS);
  var pageType = 'unknown';
  var lastDetect = null;
  var attempted = false;
  var attemptCount = 0;
  var lastAttemptAt = 0;
  var submitting = false;
  var result = null; // 'ok' | 'fail' | 'noform' | 'nocfg'

  // ============ 工具 ============
  function log(msg, level) {
    try {
      chrome.runtime.sendMessage({ type: 'CONTENT_LOG', msg: msg, level: level || 'info', url: location.href });
    } catch (e) {
      /* 扩展被重载时可能失败，忽略 */
    }
  }

  function isVisible(el) {
    if (!el || !el.getBoundingClientRect) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var st = window.getComputedStyle(el);
    if (!st || st.display === 'none' || st.visibility === 'hidden' || Number(st.opacity) === 0) return false;
    return true;
  }

  function safeQuery(sel) {
    if (!sel) return null;
    try {
      var el = document.querySelector(sel);
      return el && isVisible(el) ? el : el || null;
    } catch (e) {
      return null;
    }
  }

  function textOf(el) {
    if (!el) return '';
    return ((el.innerText || el.textContent || '') + ' ' + (el.value || '') + ' ' + (el.getAttribute('title') || '')).trim();
  }

  function inputs() {
    return Array.prototype.slice.call(document.querySelectorAll('input')).filter(function (i) {
      var t = (i.type || 'text').toLowerCase();
      return t !== 'hidden' && isVisible(i);
    });
  }

  function scoreOf(el, hint, penalize) {
    var s = 0;
    var hay = [
      el.name,
      el.id,
      el.className && typeof el.className === 'string' ? el.className : '',
      el.getAttribute('placeholder'),
      el.getAttribute('aria-label'),
      el.getAttribute('autocomplete'),
      el.getAttribute('data-name'),
      el.getAttribute('data-field'),
      el.getAttribute('v-model'),
      el.getAttribute('formcontrolname')
    ]
      .filter(Boolean)
      .join(' ');
    if (hint.test(hay)) s += 4;
    if (el.getAttribute('placeholder') && hint.test(el.getAttribute('placeholder'))) s += 3;
    if (penalize && penalize.test(hay)) s -= 6;
    return s;
  }

  function findByLabelText(el) {
    // 有些门户没有 placeholder，只有外层 label / 前面的文字
    try {
      var scope = el.closest ? el.closest('div,li,form,p') : null;
      var txt = scope ? scope.innerText || '' : '';
      return txt.slice(0, 60);
    } catch (e) {
      return '';
    }
  }

  // ============ 识别 ============
  function detectFields() {
    var list = inputs();
    var userEl = null;
    var passEl = null;

    // 1) 自定义选择器优先
    if (cfg.selectorUser) userEl = safeQuery(cfg.selectorUser);
    if (cfg.selectorPass) passEl = safeQuery(cfg.selectorPass);

    // 2) 密码框
    if (!passEl) {
      var passes = list.filter(function (i) {
        return (i.type || '').toLowerCase() === 'password';
      });
      if (passes.length === 1) passEl = passes[0];
      else if (passes.length > 1) {
        passes.sort(function (a, b) {
          return scoreOf(b, PASS_HINT) - scoreOf(a, PASS_HINT);
        });
        passEl = passes[0];
      }
    }

    // 3) 账号框
    if (!userEl) {
      var cands = list.filter(function (i) {
        if (i === passEl) return false;
        var t = (i.type || 'text').toLowerCase();
        if (['checkbox', 'radio', 'submit', 'button', 'reset', 'file', 'image', 'range'].indexOf(t) >= 0) return false;
        return i !== passEl;
      });
      cands.forEach(function (i) {
        i.__s = scoreOf(i, LOGIN_HINT, /search|searchbox|查询|验证码|captcha|code|phone|mobile|手机/i);
        if (i.__s <= 0 && findByLabelText(i) && LOGIN_HINT.test(findByLabelText(i))) i.__s += 2;
      });
      cands.sort(function (a, b) {
        return (b.__s || 0) - (a.__s || 0);
      });
      userEl = cands[0] || null;
    }

    // 4) 登录按钮
    var btn = null;
    if (cfg.selectorSubmit) btn = safeQuery(cfg.selectorSubmit);
    if (!btn) {
      var nodes = Array.prototype.slice.call(
        document.querySelectorAll('button,a,div,span,input[type=submit],input[type=button],li')
      );
      var best = null;
      var bestScore = 0;
      nodes.forEach(function (n) {
        if (!isVisible(n)) return;
        if (n.querySelector && n.querySelector('input,button,a')) return; // 取最内层
        var isClickableTag = /^(BUTTON|A|INPUT|LI)$/.test(n.tagName) || n.getAttribute('role') === 'button';
        var t = textOf(n);
        var s = 0;
        if (SUBMIT_TEXT.test(t)) s += 5;
        if (/login|submit|denglu/i.test((n.id || '') + ' ' + (n.className || ''))) s += 4;
        if (isClickableTag) s += 2;
        if (t.length > 30) s -= 2;
        if (s > bestScore) {
          bestScore = s;
          best = n;
        }
      });
      if (bestScore >= 4) btn = best;
    }

    return {
      user: userEl || null,
      pass: passEl || null,
      btn: btn || null,
      inputCount: list.length
    };
  }

  function describe(el) {
    if (!el) return '(未找到)';
    var tag = el.tagName.toLowerCase();
    var id = el.id ? '#' + el.id : '';
    var nm = el.name ? '[name=' + el.name + ']' : '';
    var ph = el.getAttribute('placeholder');
    return tag + id + nm + (ph ? ' 占位符="' + ph + '"' : '') + (el.className && typeof el.className === 'string' && el.className ? ' .' + String(el.className).split(/\s+/)[0] : '');
  }

  function selectorOf(el) {
    if (!el || !el.tagName) return '';
    if (el.id) return '#' + el.id;
    var parts = [];
    var cur = el;
    while (cur && cur.tagName && parts.length < 5) {
      var p = cur.tagName.toLowerCase();
      if (cur.name) {
        parts.unshift(p + '[name="' + cur.name + '"]');
        break;
      }
      var parent = cur.parentElement;
      if (parent) {
        var sibs = Array.prototype.filter.call(parent.children, function (c) {
          return c.tagName === cur.tagName;
        });
        if (sibs.length > 1) p += ':nth-of-type(' + (sibs.indexOf(cur) + 1) + ')';
      }
      parts.unshift(p);
      cur = cur.parentElement;
    }
    return parts.join(' > ');
  }

  // ============ 判断页面类型 ============
  function detectPageType() {
    var bodyText = '';
    try {
      bodyText = (document.body && document.body.innerText) || '';
    } catch (e) {
      bodyText = '';
    }
    var f = detectFields();
    lastDetect = f;
    var hasForm = !!(f.pass || f.user);

    if (location.href.indexOf('logout') >= 0) return 'online';
    if (ONLINE_TEXT.test(bodyText) && !f.pass) return 'online';
    if (hasForm) return 'login';
    if (LOGIN_PAGE_TEXT.test(bodyText)) return 'login';
    return 'unknown';
  }

  // ============ 填表 ============
  function setValue(el, val) {
    try {
      el.focus();
      el.value = val;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'a' }));
      el.blur();
      return String(el.value) === String(val);
    } catch (e) {
      return false;
    }
  }

  function simulateClick(el) {
    try {
      ['mousedown', 'mouseup', 'click'].forEach(function (type) {
        el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
      });
      if (typeof el.click === 'function') el.click();
      return true;
    } catch (e) {
      return false;
    }
  }

  function findNativeSubmit(f) {
    if (!f || !f.user || !f.user.form) return null;
    return f.user.form.querySelector('button[type=submit],input[type=submit]');
  }

  // ============ 登录主流程 ============
  function attemptLogin(reason) {
    return new Promise(function (resolve) {
      if (!cfg.enabled) return resolve({ ok: false, reason: 'disabled' });
      if (pageType !== 'login') return resolve({ ok: false, reason: 'not-login-page' });
      if (!cfg.username || !cfg.password) {
        result = 'nocfg';
        log('未配置账号或密码，跳过自动登录', 'warn');
        report('need-config');
        return resolve({ ok: false, reason: 'no-credentials' });
      }
      if (submitting) return resolve({ ok: false, reason: 'busy' });
      if (attemptCount >= Math.max(1, Number(cfg.maxRetry) || 3)) {
        log('已达最大重试次数(' + cfg.maxRetry + ')，停止尝试，请检查密码是否正确', 'warn');
        return resolve({ ok: false, reason: 'max-retry' });
      }

      var f = detectFields();
      lastDetect = f;
      if (!f.pass && !f.user) {
        result = 'noform';
        log('未识别到登录表单（页面结构可能已改版），请在弹窗中手动填写选择器', 'warn');
        report('no-form');
        return resolve({ ok: false, reason: 'no-form' });
      }

      submitting = true;
      attemptCount++;
      lastAttemptAt = Date.now();
      log('第 ' + attemptCount + ' 次自动登录：账号框=' + describe(f.user) + '，密码框=' + describe(f.pass) + (reason ? '（' + reason + '）' : ''));

      setValue(f.user, cfg.username);
      setValue(f.pass, cfg.password);

      var clicked = false;
      if (f.btn) clicked = simulateClick(f.btn);
      if (!clicked) {
        var native = findNativeSubmit(f);
        if (native) clicked = simulateClick(native);
      }
      if (!clicked && f.pass && f.pass.form) {
        log('未找到登录按钮，改用 form.submit()', 'warn');
        try {
          f.pass.form.submit();
          clicked = true;
        } catch (e) {
          /* ignore */
        }
      }

      // 等待页面跳转 / 错误提示
      var settled = false;
      var finish = function (r) {
        if (settled) return;
        settled = true;
        submitting = false;
        result = r.ok ? 'ok' : 'fail';
        report(r.ok ? 'login-ok' : 'login-fail', r.reason || '');
        resolve(r);
      };

      var iv = setInterval(function () {
        var t = '';
        try {
          t = (document.body && document.body.innerText) || '';
        } catch (e) {
          t = '';
        }
        if (ONLINE_TEXT.test(t) && !detectFields().pass) return finish({ ok: true, method: 'dom-online' });
        if (attemptCount > 0 && FAIL_TEXT.test(t.slice(0, 3000)) && /失败|错误|不正确|无效|不存在|停用|欠费/.test(t.slice(0, 3000))) {
          return finish({ ok: false, reason: 'rejected: ' + t.replace(/\s+/g, ' ').slice(0, 120) });
        }
      }, 400);

      setTimeout(function () {
        clearInterval(iv);
        if (settled) return;
        // 页面没跳转也没报错：可能是 AJAX 提交，交给 background 判定
        finish({ ok: false, reason: 'no-response', pending: true });
      }, 12000);

      if (!clicked) {
        clearInterval(iv);
        finish({ ok: false, reason: 'no-submit-button' });
      }
    });
  }

  function report(state, extra) {
    try {
      chrome.runtime.sendMessage({
        type: 'REPORT',
        state: state,
        extra: extra || '',
        url: location.href,
        online: pageType === 'online'
      });
    } catch (e) {
      /* ignore */
    }
  }

  // ============ 初始化 ============
  function refreshConfig() {
    return chrome.storage.local.get('wfu_config').then(function (got) {
      cfg = Object.assign({}, DEFAULTS, got && got.wfu_config ? got.wfu_config : {});
      return cfg;
    });
  }

  function waitReady() {
    return new Promise(function (resolve) {
      if (document.readyState === 'complete' || document.readyState === 'interactive') return resolve();
      document.addEventListener('DOMContentLoaded', function () {
        resolve();
      });
      setTimeout(resolve, 6000);
    });
  }

  function collectProbe() {
    try {
      var p = window.__WFU_PROBE__;
      if (!p) return null;
      return {
        net: (p.net || []).slice(-25),
        errs: (p.errs || []).slice(-10)
      };
    } catch (e) {
      return null;
    }
  }

  function status() {
    var f = lastDetect || detectFields();
    var net = (collectProbe() || {}).net || [];
    return {
      url: location.href,
      pageType: pageType,
      result: result,
      frame: window.top === window ? 'top' : 'iframe',
      fields: {
        user: describe(f.user),
        pass: describe(f.pass),
        btn: describe(f.btn)
      },
      selectors: {
        user: selectorOf(f.user),
        pass: selectorOf(f.pass),
        btn: selectorOf(f.btn)
      },
      inputs: f.inputCount,
      attempted: attemptCount,
      hasCred: !!(cfg.username && cfg.password),
      enabled: !!cfg.enabled,
      net: net,
      probeAvailable: !!window.__WFU_PROBE__
    };
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg || !msg.type) return;
    if (msg.type === 'PING') {
      sendResponse({ ok: true, pageType: pageType, state: status() });
      return true;
    }
    if (msg.type === 'DETECT') {
      pageType = detectPageType();
      sendResponse({ ok: true, state: status() });
      return true;
    }
    if (msg.type === 'DO_LOGIN') {
      refreshConfig().then(function () {
        pageType = detectPageType();
        attemptCount = 0;
        return attemptLogin('手动触发');
      }).then(function (r) {
        sendResponse({ ok: !!r.ok, result: r, state: status() });
      });
      return true;
    }
    if (msg.type === 'FILL_ONLY') {
      refreshConfig().then(function () {
        var f = detectFields();
        if (!f.user && !f.pass) return { ok: false, reason: 'no-form' };
        if (f.user) setValue(f.user, cfg.username);
        if (f.pass) setValue(f.pass, cfg.password);
        return { ok: true };
      }).then(function (r) {
        sendResponse(r);
      });
      return true;
    }
    if (msg.type === 'STATUS') {
      sendResponse({ ok: true, state: status() });
      return true;
    }
  });

  function boot(reason) {
    refreshConfig().then(function () {
      return waitReady();
    }).then(function () {
      pageType = detectPageType();
      log(
        '页面识别：' + pageType + '，账号框 ' + describe(lastDetect && lastDetect.user) + '，密码框 ' + describe(lastDetect && lastDetect.pass) + '，按钮 ' + describe(lastDetect && lastDetect.btn),
        'info'
      );
      report('page-detected:' + pageType);
      if (pageType === 'online') {
        report('update', 'online');
        return null;
      }
      if (pageType !== 'login') return null;
      if (!cfg.autoLogin) return null;
      if (!cfg.username || !cfg.password) {
        result = 'nocfg';
        report('need-config');
        return null;
      }
      if (msg_once()) return null;
      return new Promise(function (r) {
        setTimeout(r, 700);
      }).then(function () {
        return attemptLogin(reason || '页面加载');
      });
    });
  }

  function msg_once() {
    // 同一页面（含 SPA 路由）只自动尝试一次
    if (attempted) return true;
    attempted = true;
    return false;
  }

  boot('页面加载');

  // SPA 门户：登录页可能不重新加载就出现，监听一次变化再试
  var moTimer = null;
  var mo = new MutationObserver(function () {
    if (pageType === 'login' || submitting) return;
    clearTimeout(moTimer);
    moTimer = setTimeout(function () {
      if (pageType === 'login' || submitting) return;
      var t = detectPageType();
      if (t === 'login') {
        pageType = 'login';
        result = null;
        attempted = false;
        boot('检测到登录表单出现');
      } else if (t !== 'unknown') {
        pageType = t;
      }
    }, 600);
  });
  try {
    mo.observe(document.documentElement || document, { childList: true, subtree: true });
    setTimeout(function () {
      mo.disconnect();
    }, 120000);
  } catch (e) {
    /* ignore */
  }

  window.addEventListener('beforeunload', function () {
    report('unload', pageType);
  });
})();
