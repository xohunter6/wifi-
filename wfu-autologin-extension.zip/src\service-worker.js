/**
 * service-worker.js —— 后台逻辑
 *   · 定时探测校园网在线状态（读取门户返回的 HTML 判定）
 *   · 掉线时通知 / 自动重新打开门户页触发登录
 *   · 与 content.js 通信，汇总统计与诊断日志
 */
import {
  ONLINE_KEYWORDS,
  LOGIN_KEYWORDS,
  loadConfig,
  saveConfig,
  loadStats,
  saveStats,
  appendLog,
  normalizeUrl,
  samePortal,
  isLoginPage,
  currentMatchPatterns,
  hostMatchesPattern,
  fmtTime
} from './shared.js';

const ALARM_WATCH = 'wfu-watch';
const BADGE = { online: ['在线', '#1a9c4b'], offline: ['离线', '#d94b2b'], unknown: ['', '#888888'], nocfg: ['未设置', '#888888'] };

let probing = false;

/* ------------------------------------------------------------------ */
/* 工具                                                                */
/* ------------------------------------------------------------------ */

async function setBadge(state, cfg) {
  if (cfg && cfg.badge === false) {
    await chrome.action.setBadgeText({ text: '' });
    return;
  }
  const info = BADGE[state] || BADGE.unknown;
  try {
    await chrome.action.setBadgeText({ text: info[0] });
    await chrome.action.setBadgeBackgroundColor({ color: info[1] });
    await chrome.action.setTitle({
      title:
        state === 'online'
          ? '潍院校园网：在线'
          : state === 'offline'
          ? '潍院校园网：未认证（会自动重登）'
          : state === 'nocfg'
          ? '潍院校园网：请先在弹窗里填写账号密码'
          : '潍院校园网自动登录'
    });
  } catch (e) {
    /* ignore */
  }
}

function probeUrlOf(cfg) {
  return normalizeUrl(cfg.probeUrl || cfg.portalOrigin || cfg.portalUrl);
}

function classifyHtml(html) {
  const h = String(html || '');
  const onlineHits = ONLINE_KEYWORDS.filter((k) => h.indexOf(k) >= 0);
  const loginHits = LOGIN_KEYWORDS.filter((k) => h.indexOf(k) >= 0);
  if (onlineHits.length && onlineHits.indexOf('在线时长') >= 0) return { state: 'online', onlineHits, loginHits };
  if (loginHits.length >= 2 && onlineHits.length === 0) return { state: 'login', onlineHits, loginHits };
  if (onlineHits.length) return { state: 'online', onlineHits, loginHits };
  if (loginHits.length) return { state: 'login', onlineHits, loginHits };
  return { state: 'unknown', onlineHits, loginHits };
}

async function probeOnce(cfg, opts) {
  const url = probeUrlOf(cfg);
  const t0 = Date.now();
  try {
    const res = await fetch(url, {
      method: 'GET',
      credentials: 'include',
      cache: 'no-store',
      redirect: 'follow',
      headers: { Accept: 'text/html,application/xhtml+xml' }
    });
    const html = await res.text();
    const cls = classifyHtml(html);
    return { ok: true, ms: Date.now() - t0, url, status: res.status, finalUrl: res.url, ...cls };
  } catch (e) {
    return { ok: false, ms: Date.now() - t0, url, error: String((e && e.message) || e), state: 'unknown' };
  }
}

async function activePortalTabs(cfg) {
  const tabs = await chrome.tabs.query({});
  return tabs.filter((t) => t.url && (samePortal(t.url, cfg) || isLoginPage(t.url, cfg)));
}

/** 向页面里的 content.js 发消息；若未注入则尝试 programmatic 注入 */
async function tellTab(tabId, msg) {
  try {
    return await chrome.tabs.sendMessage(tabId, msg);
  } catch (e) {
    // content script 未就绪（例如扩展刚安装后已打开的旧标签页）
    try {
      await chrome.scripting.executeScript({ target: { tabId, allFrames: false }, files: ['src/probe.js', 'src/content.js'] });
      await new Promise((r) => setTimeout(r, 400));
      return await chrome.tabs.sendMessage(tabId, msg);
    } catch (e2) {
      return { ok: false, error: String((e2 && e2.message) || e2) };
    }
  }
}

async function keepAlive(ms) {
  // MV3 service worker 可能在等着的时候被回收，这里做一次无副作用的续命
  return new Promise((r) => setTimeout(r, ms));
}

/* ------------------------------------------------------------------ */
/* 核心：检查 + 必要时重登                                             */
/* ------------------------------------------------------------------ */

async function checkAndMaybeLogin(manual) {
  if (probing && !manual) return { skipped: 'busy' };
  probing = true;
  try {
    const cfg = await loadConfig();
    if (!cfg.enabled) {
      await setBadge('unknown', cfg);
      return { state: 'disabled' };
    }
    if (!cfg.username || !cfg.password) {
      await saveStats({ lastProbe: Date.now(), lastState: 'nocfg' });
      await setBadge('nocfg', cfg);
      return { state: 'nocfg' };
    }

    const r = await probeOnce(cfg);
    await appendLog({
      level: r.state === 'online' ? 'info' : 'warn',
      msg: '探测 ' + r.url + ' → ' + r.state + (r.ok ? ' (HTTP ' + r.status + ', ' + r.ms + 'ms)' : ' 失败: ' + r.error)
    });

    if (r.state === 'online') {
      const st = await loadStats();
      await saveStats({
        lastProbe: Date.now(),
        lastState: 'online',
        onlineSince: st.lastState === 'online' && st.onlineSince ? st.onlineSince : Date.now(),
        lastResult: '在线'
      });
      await setBadge('online', cfg);
      return { state: 'online', probe: r };
    }

    if (r.state === 'unknown' && !r.ok) {
      // 连门户都访问不到：通常是没连上校园 WiFi，不折腾
      await saveStats({ lastProbe: Date.now(), lastState: 'offline', lastResult: '无法访问门户: ' + r.error });
      await setBadge('offline', cfg);
      return { state: 'offline', reason: 'unreachable', probe: r };
    }

    // 判定为未认证 → 尝试去登录
    await saveStats({ lastProbe: Date.now(), lastState: 'offline', lastResult: '检测到未认证，尝试重登' });
    await setBadge('offline', cfg);

    const tabs = await activePortalTabs(cfg);
    const loginTab = tabs.find((t) => isLoginPage(t.url, cfg));
    if (loginTab) {
      const res = await tellTab(loginTab.id, { type: 'DO_LOGIN' });
      if (res && res.ok) return { state: 'relogin-ok', tabId: loginTab.id };
      if (cfg.notify) notify('自动重登未成功', '已打开门户页但仍未登录成功，请查看是否需要手动输入验证码。');
      return { state: 'relogin-fail', tabId: loginTab.id, res };
    }

    // 没有门户标签页：开一个（默认后台打开，不打断你）
    if (cfg.autoReopen) {
      const tab = await chrome.tabs.create({ url: cfg.portalUrl, active: false });
      if (cfg.notify) notify('检测到校园网掉线', '已为你打开认证页面并自动重登。');
      await appendLog({ level: 'warn', msg: '掉线：已打开门户页 ' + cfg.portalUrl + '（标签 ' + tab.id + '）' });
      return { state: 'reopened', tabId: tab.id };
    }

    if (cfg.notify) notify('检测到校园网掉线', '请打开 ' + cfg.portalUrl + ' 重新认证。');
    return { state: 'offline-notify-only' };
  } finally {
    probing = false;
  }
}

function notify(title, message) {
  try {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icons/icon128.png'),
      title,
      message,
      priority: 1
    });
  } catch (e) {
    /* ignore */
  }
}

/* ------------------------------------------------------------------ */
/* 定时任务                                                            */
/* ------------------------------------------------------------------ */

async function ensureAlarm() {
  const cfg = await loadConfig();
  const period = Math.max(30, Number(cfg.watchInterval) || 60);
  const existing = await chrome.alarms.get(ALARM_WATCH);
  if (!cfg.watchEnabled) {
    if (existing) await chrome.alarms.clear(ALARM_WATCH);
    return;
  }
  if (!existing || existing.periodInMinutes !== period / 60) {
    await chrome.alarms.create(ALARM_WATCH, { periodInMinutes: period / 60, delayInMinutes: 0.2 });
  }
}

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === ALARM_WATCH) checkAndMaybeLogin(false);
});

chrome.runtime.onInstalled.addListener(() => {
  ensureAlarm();
  appendLog({ level: 'info', msg: '扩展已安装/更新，后台守护已就绪' });
  checkAndMaybeLogin(false);
});

chrome.runtime.onStartup.addListener(() => {
  ensureAlarm();
  checkAndMaybeLogin(false);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.wfu_config) ensureAlarm();
});

/* ------------------------------------------------------------------ */
/* 消息处理                                                            */
/* ------------------------------------------------------------------ */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === 'CONTENT_LOG') {
    appendLog({ level: msg.level || 'info', msg: msg.msg, url: msg.url }).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === 'REPORT') {
    handleReport(msg, sender).then((r) => sendResponse({ ok: true, ...r }));
    return true;
  }

  if (msg.type === 'GET_STATE') {
    getFullState().then((s) => sendResponse(s));
    return true;
  }

  if (msg.type === 'SAVE_CONFIG') {
    (async () => {
      const next = await saveConfig(msg.patch || {});
      await appendLog({ level: 'info', msg: '保存配置' + (msg.patch && msg.patch.username != null ? '（账号：' + next.username + '）' : '') });
      await reinject(next);
      checkAndMaybeLogin(true);
      const s = await getFullState();
      sendResponse(s);
    })();
    return true;
  }

  if (msg.type === 'PROBE_NOW') {
    (async () => {
      const r = await checkAndMaybeLogin(true);
      const s = await getFullState();
      sendResponse({ ...s, probe: r });
    })();
    return true;
  }

  if (msg.type === 'DO_LOGIN') {
    (async () => {
      const cfg = await loadConfig();
      if (!cfg.username || !cfg.password) {
        sendResponse(await getFullState().then((s) => ({ ...s, error: '请先填写并保存账号密码' })));
        return;
      }
      const tabs = await activePortalTabs(cfg);
      const loginTab = tabs.find((t) => isLoginPage(t.url, cfg));
      let tabId;
      if (loginTab) {
        tabId = loginTab.id;
        await chrome.tabs.update(tabId, { active: true });
      } else {
        const tab = await chrome.tabs.create({ url: cfg.portalUrl, active: true });
        tabId = tab.id;
      }
      await keepAlive(1500);
      const res = await tellTab(tabId, { type: 'DO_LOGIN' });
      const s = await getFullState();
      sendResponse({ ...s, loginResult: res });
    })();
    return true;
  }

  if (msg.type === 'CLEAR_LOG') {
    chrome.storage.local.set({ wfu_log: [] }).then(() => sendResponse({ ok: true }));
    return true;
  }

  return;
});

async function handleReport(msg, sender) {
  const cfg = await loadConfig();
  if (msg.state === 'login-ok') {
    const st = await loadStats();
    await saveStats({ lastState: 'online', onlineSince: Date.now(), loginCount: (st.loginCount || 0) + 1, lastResult: '登录成功' });
    await setBadge('online', cfg);
    await appendLog({ level: 'info', msg: '登录成功 ✓ ' + (msg.url || '') });
    return { state: 'online' };
  }
  if (msg.state === 'login-fail') {
    const st = await loadStats();
    await saveStats({ lastState: 'offline', failCount: (st.failCount || 0) + 1, lastResult: '登录失败: ' + (msg.extra || '') });
    await setBadge('offline', cfg);
    await appendLog({ level: 'error', msg: '登录失败 ✗ ' + (msg.extra || '') });
    return { state: 'offline' };
  }
  if (msg.state === 'need-config') {
    await setBadge('nocfg', cfg);
    return { state: 'nocfg' };
  }
  if (msg.state === 'no-form') {
    await appendLog({ level: 'warn', msg: '页面里找不到登录表单，可能需要手动指定选择器' });
    return { state: 'no-form' };
  }
  if (msg.state === 'page-detected:online' || (msg.state === 'update' && msg.extra === 'online')) {
    const st = await loadStats();
    await saveStats({ lastState: 'online', onlineSince: st.onlineSince || Date.now(), lastResult: '门户显示已在线' });
    await setBadge('online', cfg);
    return { state: 'online' };
  }
  return { state: 'ok' };
}

async function reinject(cfg) {
  const patterns = await currentMatchPatterns(cfg);
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) {
    if (!t.url || !/^https?:/.test(t.url)) continue;
    if (!samePortal(t.url, cfg) && !patterns.some((p) => hostMatchesPattern(p, t.url))) continue;
    try {
      await chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, files: ['src/probe.js', 'src/content.js'] });
    } catch (e) {
      await appendLog({
        level: 'warn',
        msg: '向 ' + t.url + ' 注入脚本失败（额外地址需要先授权该站点权限）：' + String((e && e.message) || e)
      });
    }
  }
  return patterns;
}

function matchPattern(pattern, url) {
  return hostMatchesPattern(pattern, url);
}

/* ------------------------------------------------------------------ */
/* 状态聚合（给弹窗用）                                                */
/* ------------------------------------------------------------------ */

async function getFullState() {
  const cfg = await loadConfig();
  const cfgSafe = { ...cfg };
  // 不回传明文密码到界面，只回传是否已设置
  delete cfgSafe.password;
  cfgSafe.passwordSet = !!cfg.password;

  const stats = await loadStats();
  const got = await chrome.storage.local.get('wfu_log');
  const log = Array.isArray(got.wfu_log) ? got.wfu_log.slice(-80).reverse() : [];
  const tabs = await activePortalTabs(cfg);
  return {
    ok: true,
    config: cfgSafe,
    stats: {
      ...stats,
      onlineText: stats.lastState === 'online' ? '在线' : stats.lastState === 'offline' ? '未认证/掉线' : stats.lastState === 'nocfg' ? '未配置账号' : '未知',
      lastProbeText: stats.lastProbe ? fmtTime(stats.lastProbe) : '—',
      sinceText: stats.onlineSince ? fmtTime(stats.onlineSince) : '—'
    },
    log,
    portalTabs: tabs.map((t) => ({ id: t.id, url: t.url, title: t.title })),
    probeUrl: probeUrlOf(cfg)
  };
}
