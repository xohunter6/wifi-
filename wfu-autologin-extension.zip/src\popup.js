/**
 * popup.js —— 设置面板逻辑
 */
const $ = (id) => document.getElementById(id);

const TEXT_FIELDS = [
  'username',
  'portalUrl',
  'probeUrl',
  'selectorUser',
  'selectorPass',
  'selectorSubmit',
  'extraMatchUrls'
];
const NUM_FIELDS = ['watchInterval', 'maxRetry'];
const CHECK_FIELDS = ['enabled', 'autoLogin', 'watchEnabled', 'autoReopen', 'notify', 'badge'];

let snap = null;
let passwordTouched = false;
let filled = false;

function send(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (res) => {
      if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
      else resolve(res || { ok: false, error: 'no response' });
    });
  });
}

function toast(text, ms) {
  const el = $('toast');
  el.textContent = text;
  el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), ms || 2200);
}

function fillForm(cfg) {
  TEXT_FIELDS.forEach((k) => {
    if ($(k)) $(k).value = cfg[k] || '';
  });
  NUM_FIELDS.forEach((k) => {
    if ($(k)) $(k).value = cfg[k] != null ? cfg[k] : '';
  });
  CHECK_FIELDS.forEach((k) => {
    if ($(k)) $(k).checked = cfg[k] !== false;
  });
  $('password').value = '';
  $('password').placeholder = cfg.passwordSet ? '已保存（留空=不修改）' : '请输入密码';
}

function renderState(s) {
  snap = s;
  const cfg = s.config || {};
  // 首次只回填用户尚未编辑过的字段，避免覆盖正在输入的内容
  if (!filled) {
    if (!$('username').value && cfg.username) $('username').value = cfg.username;
    if (!$('portalUrl').value && cfg.portalUrl) $('portalUrl').value = cfg.portalUrl;
  }

  $('portalHint').textContent = s.probeUrl || cfg.portalUrl || '—';
  $('lastProbe').textContent = s.stats.lastProbeText;
  $('onlineSince').textContent = s.stats.sinceText;
  $('lastResult').textContent = s.stats.lastResult || '—';
  $('counters').textContent = `登录成功 ${s.stats.loginCount || 0} 次 / 失败 ${s.stats.failCount || 0} 次`;

  const badge = $('stateBadge');
  badge.textContent = s.stats.onlineText;
  badge.className = 'badge ' + (s.stats.lastState === 'online' ? 'online' : s.stats.lastState === 'offline' ? 'offline' : '');

  renderLog(s.log || []);
}

function renderLog(list) {
  if (!list.length) {
    $('log').textContent = '（暂无日志）';
    return;
  }
  const lines = list.map((e) => {
    const d = new Date(e.t || Date.now());
    const p = (n) => String(n).padStart(2, '0');
    const t = `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
    const mark = e.level === 'error' ? '✗' : e.level === 'warn' ? '!' : '·';
    return `${t} ${mark} ${e.msg || ''}`;
  });
  $('log').textContent = lines.join('\n');
}

function collectPatch() {
  const patch = {};
  TEXT_FIELDS.forEach((k) => {
    if ($(k)) patch[k] = $(k).value.trim();
  });
  NUM_FIELDS.forEach((k) => {
    if ($(k)) patch[k] = Number($(k).value) || (k === 'watchInterval' ? 60 : 3);
  });
  CHECK_FIELDS.forEach((k) => {
    if ($(k)) patch[k] = $(k).checked;
  });
  if (passwordTouched) patch.password = $('password').value;
  return patch;
}

async function save(quiet) {
  const patch = collectPatch();
  if (!patch.username || !(patch.password || (snap && snap.config.passwordSet))) {
    toast('请填写账号和密码');
  }
  const res = await send({ type: 'SAVE_CONFIG', patch });
  renderState(res);
  if (snap && snap.config) {
    fillForm({ ...snap.config, passwordSet: !!snap.config.passwordSet || !!patch.password, ...patch, password: '' });
  }
  passwordTouched = false;
  if (!quiet) toast(patch.enabled === false ? '已保存（总开关关闭）' : '已保存');
  return res;
}

/** 找到可注入的门户标签页；没有就返回 null */
async function findPortalTab() {
  const all = await chrome.tabs.query({});
  const origin = (snap && snap.probeUrl) || '';
  let host = '';
  try {
    host = new URL(origin).host;
  } catch (e) {
    host = '';
  }
  const portalTabs = all.filter((t) => t.url && t.url.indexOf(host || '210.44.64.60') >= 0);
  const login = portalTabs.find((t) => t.url && t.url.indexOf('login') >= 0);
  return login || portalTabs[0] || null;
}

async function ensureInjected(tabId) {
  try {
    const ping = await chrome.tabs.sendMessage(tabId, { type: 'PING' });
    if (ping && ping.ok) return ping;
  } catch (e) {
    /* 未注入，继续 */
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      files: ['src/probe.js', 'src/content.js']
    });
    await new Promise((r) => setTimeout(r, 500));
    return await chrome.tabs.sendMessage(tabId, { type: 'PING' });
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}

function renderDetect(res, tab) {
  if (!res || !res.ok || !res.state) {
    $('log').textContent =
      '（识别失败）\n' + JSON.stringify(res && res.error ? res.error : res, null, 2) + '\n\n请确认当前标签页已打开校园网门户登录页。';
    toast('请先打开门户登录页');
    return;
  }
  const s = res.state;
  const lines = [];
  lines.push('页面地址: ' + s.url);
  lines.push('页面类型: ' + s.pageType + (s.frame === 'iframe' ? '（内嵌 iframe）' : ''));
  lines.push('已注入探测: ' + (s.probeAvailable ? '是' : '否'));
  lines.push('可输入框数量: ' + s.inputs);
  lines.push('');
  lines.push('识别结果');
  lines.push('  账号框: ' + s.fields.user);
  lines.push('  密码框: ' + s.fields.pass);
  lines.push('  登录钮: ' + s.fields.btn);
  lines.push('');
  lines.push('对应选择器（可直接粘到高级设置里）');
  lines.push('  账号: ' + (s.selectors.user || '—'));
  lines.push('  密码: ' + (s.selectors.pass || '—'));
  lines.push('  按钮: ' + (s.selectors.btn || '—'));
  lines.push('');
  lines.push('已保存账号: ' + (s.hasCred ? '是' : '否') + ' / 自动登录开关: ' + (s.enabled ? '开' : '关'));
  if (s.net && s.net.length) {
    lines.push('');
    lines.push('页面发出的请求（最近 ' + s.net.length + ' 条，来自注入探测）');
    s.net.slice(-12).forEach((n) => {
      lines.push('  [' + n.kind + '] ' + (n.method || 'GET') + ' ' + String(n.url || ''));
      if (n.body) lines.push('        body: ' + n.body);
    });
  } else {
    lines.push('');
    lines.push('页面请求: 暂无记录（若点了登录仍为空，可能是页面在 iframe 中或用了原生 form 提交）');
  }
  $('log').textContent = lines.join('\n');
  toast('识别完成：' + s.pageType);
}

/* ---------------- 事件绑定 ---------------- */
$('password').addEventListener('input', () => {
  passwordTouched = true;
});

$('save').addEventListener('click', () => save(false));

$('probe').addEventListener('click', async () => {
  toast('探测中…');
  const res = await send({ type: 'PROBE_NOW' });
  renderState(res);
  if (res && res.probe) toast('探测结果：' + (res.probe.state || '未知'));
  else toast('已触发探测');
});

$('login').addEventListener('click', async () => {
  await save(true);
  toast('正在登录…');
  const res = await send({ type: 'DO_LOGIN' });
  renderState(res);
  const r = res && res.loginResult;
  if (r && r.ok) toast('登录成功 ✓', 3000);
  else if (r && r.result && r.result.reason) toast('结果：' + r.result.reason, 3500);
  else toast('已打开门户页，正在尝试登录', 3000);
});

$('test').addEventListener('click', async () => {
  await save(true);
  const tab = await findPortalTab();
  if (!tab) {
    toast('请先打开校园网门户登录页');
    $('log').textContent = '（未找到门户标签页）\n请先访问 ' + ((snap && snap.probeUrl) || 'http://210.44.64.60/gportal/web/login') + ' 再点“测试识别”。';
    return;
  }
  const res = await ensureInjected(tab.id);
  renderDetect(res, tab);
});

$('clearLog').addEventListener('click', async (e) => {
  e.preventDefault();
  await send({ type: 'CLEAR_LOG' });
  $('log').textContent = '（暂无日志）';
  toast('日志已清空');
});

/* ---------------- 初始化 ---------------- */
(async function init() {
  const s = await send({ type: 'GET_STATE' });
  if (!s || !s.ok) {
    $('log').textContent = '无法连接后台服务，请重新加载扩展。\n' + JSON.stringify(s, null, 2);
    return;
  }
  fillForm(s.config);
  filled = true;
  renderState(s);
  // 打开弹窗时顺手做一次轻量探测
  send({ type: 'PROBE_NOW' }).then((r) => {
    if (r && r.ok) renderState(r);
  });
})();
