/**
 * probe.js —— 注入到页面主世界（document_start）
 *
 * 目的：记录门户页面自己发出的网络请求，方便在识别不到表单字段时
 * 直接看出登录接口的真实地址与参数名（在弹窗的“诊断日志”里查看）。
 *
 * 只读取、不修改任何请求内容，不会影响页面本身的行为。
 */
(function () {
  'use strict';
  if (window.__WFU_PROBE__) return;
  window.__WFU_PROBE__ = { net: [], t0: Date.now(), errs: [] };

  var MAX = 60;

  function push(item) {
    try {
      window.__WFU_PROBE__.net.push(item);
      while (window.__WFU_PROBE__.net.length > MAX) window.__WFU_PROBE__.net.shift();
    } catch (e) {
      /* ignore */
    }
  }

  function brief(v, limit) {
    try {
      if (v == null) return '';
      var s = typeof v === 'string' ? v : String(v);
      if (s.length > (limit || 600)) s = s.slice(0, limit || 600) + '…';
      return s;
    } catch (e) {
      return '';
    }
  }

  // ---- fetch ----
  var rawFetch = window.fetch;
  if (typeof rawFetch === 'function') {
    window.fetch = function (input, init) {
      var url = '';
      var method = 'GET';
      var body = '';
      try {
        url = typeof input === 'string' ? input : input && input.url ? input.url : String(input);
        method = (init && init.method) || (input && input.method) || 'GET';
        body = (init && init.body) || '';
      } catch (e) {
        /* ignore */
      }
      var p = rawFetch.apply(this, arguments);
      try {
        p.then(function (res) {
          push({ t: Date.now(), kind: 'fetch', method: method, url: url, body: brief(body), status: res && res.status });
        }).catch(function (err) {
          push({ t: Date.now(), kind: 'fetch', method: method, url: url, body: brief(body), status: 'ERR ' + (err && err.message) });
        });
      } catch (e) {
        /* ignore */
      }
      return p;
    };
  }

  // ---- XMLHttpRequest ----
  var XO = window.XMLHttpRequest;
  if (typeof XO === 'function') {
    var open = XO.prototype.open;
    var send = XO.prototype.send;
    XO.prototype.open = function (method, url) {
      try {
        this.__wfu = { method: method, url: url };
      } catch (e) {
        /* ignore */
      }
      return open.apply(this, arguments);
    };
    XO.prototype.send = function (body) {
      var self = this;
      try {
        var meta = self.__wfu || {};
        self.addEventListener('loadend', function () {
          push({
            t: Date.now(),
            kind: 'xhr',
            method: meta.method,
            url: meta.url,
            body: brief(body),
            status: self.status
          });
        });
      } catch (e) {
        /* ignore */
      }
      return send.apply(this, arguments);
    };
  }

  // ---- 记录页面脚本错误，辅助排查 ----
  window.addEventListener(
    'error',
    function (ev) {
      try {
        window.__WFU_PROBE__.errs.push({ t: Date.now(), msg: brief(ev && ev.message, 200) });
        while (window.__WFU_PROBE__.errs.length > 20) window.__WFU_PROBE__.errs.shift();
      } catch (e) {
        /* ignore */
      }
    },
    true
  );
})();
