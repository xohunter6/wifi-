/**
 * 共享配置与工具（供 service-worker.js / popup.js 以 ES Module 方式引用）
 * content.js 是独立脚本，不 import 本文件，以免受加载方式限制。
 */

export const DEFAULT_CONFIG = {
  enabled: true,
  username: '',
  password: '',
  portalUrl: 'http://210.44.64.60/gportal/web/login',
  /** 门户同源根地址，用于轮询在线状态 */
  portalOrigin: 'http://210.44.64.60',
  /** 状态探测地址，留空则用门户根地址 */
  probeUrl: '',
  /** 除门户本身外，额外允许自动注入脚本的地址（可选，逗号或换行分隔） */
  extraMatchUrls: '',
  /** 打开门户页时自动填表并登录 */
  autoLogin: true,
  /** 定时探测在线状态 */
  watchEnabled: true,
  /** 探测间隔（秒），最小 30 */
  watchInterval: 60,
  /** 探测到掉线时自动重新打开门户登录页 */
  autoReopen: true,
  /** 掉线时发系统通知 */
  notify: true,
  /** 登录失败最大重试次数（防账号锁定） */
  maxRetry: 3,
  /** 自定义选择器：留空表示走智能识别 */
  selectorUser: '',
  selectorPass: '',
  selectorSubmit: '',
  /** 高级：登录请求体参数名映射（自动识别失败时手动指定） */
  userParam: '',
  passParam: '',
  /** 图标角标显示在线状态 */
  badge: true
};

/** 探测页面时用于判断“已在线”的关键词 */
export const ONLINE_KEYWORDS = ['在线时长', '下线', '注销', '当前在线', '已登录'];
/** 判断“未登录（登录页）”的关键词 */
export const LOGIN_KEYWORDS = ['请输入学工号', '请输入密码', '登录', '忘记', '设置密码'];

export const STORAGE_KEY = 'wfu_config';
export const STATS_KEY = 'wfu_stats';
export const LOG_KEY = 'wfu_log';

export async function loadConfig() {
  const got = await chrome.storage.local.get(STORAGE_KEY);
  const cfg = Object.assign({}, DEFAULT_CONFIG, got[STORAGE_KEY] || {});
  cfg.username = String(cfg.username || '');
  cfg.password = String(cfg.password || '');
  return cfg;
}

export async function saveConfig(patch) {
  const cur = await loadConfig();
  const next = Object.assign(cur, patch || {});
  await chrome.storage.local.set({ [STORAGE_KEY]: next });
  return next;
}

export async function loadStats() {
  const got = await chrome.storage.local.get(STATS_KEY);
  return Object.assign(
    { lastProbe: 0, lastState: 'unknown', onlineSince: 0, loginCount: 0, failCount: 0, lastResult: '' },
    got[STATS_KEY] || {}
  );
}

export async function saveStats(patch) {
  const cur = await loadStats();
  const next = Object.assign(cur, patch || {});
  await chrome.storage.local.set({ [STATS_KEY]: next });
  return next;
}

export async function appendLog(entry) {
  const got = await chrome.storage.local.get(LOG_KEY);
  const list = Array.isArray(got[LOG_KEY]) ? got[LOG_KEY] : [];
  list.push(Object.assign({ t: Date.now() }, entry));
  while (list.length > 200) list.shift();
  await chrome.storage.local.set({ [LOG_KEY]: list });
  return list;
}

/** URL 归一化：去掉末尾斜杠，忽略 hash */
export function normalizeUrl(u) {
  try {
    const x = new URL(String(u));
    x.hash = '';
    let s = x.toString();
    if (s.endsWith('/')) s = s.slice(0, -1);
    return s;
  } catch (e) {
    return String(u || '').trim();
  }
}

/** 把用户输入的额外地址转成匹配模式 */
export function extraMatchPatterns(extra) {
  const out = [];
  String(extra || '')
    .split(/[\s,;]+/)
    .map((s) => s.trim())
    .filter(Boolean)
    .forEach((s) => {
      if (s.startsWith('http://') || s.startsWith('https://')) out.push(s);
      else out.push('*://' + s.replace(/^\/+/, '') + '/*');
    });
  return out;
}

/** 实现 Chrome match-pattern 的 host 匹配（支持 *.example.com 与 * 通配） */
export function hostMatchesPattern(pattern, url) {
  try {
    const pat = String(pattern).split('//')[1] || '';
    const hostPat = pat.split('/')[0];
    const host = new URL(url).host;
    if (!hostPat) return false;
    const re =
      '^' +
      hostPat
        .replace(/[.+?^${}()|[\]\\]/g, '\\$&')
        .replace(/\*/g, '[^.:]*') +
      '$';
    return new RegExp(re, 'i').test(host);
  } catch (e) {
    return false;
  }
}

/** 依据当前配置生成需要注入的匹配规则（门户 + 额外地址） */
export async function currentMatchPatterns(cfg) {
  const base = [];
  try {
    const o = new URL(cfg.portalUrl);
    base.push(o.origin + '/*');
  } catch (e) {
    /* ignore */
  }
  return Array.from(new Set(base.concat(extraMatchPatterns(cfg.extraMatchUrls))));
}

export function samePortal(url, cfg) {
  try {
    return new URL(url).host === new URL(cfg.portalUrl).host;
  } catch (e) {
    return false;
  }
}

export function isLoginPage(url, cfg) {
  const a = normalizeUrl(url);
  const b = normalizeUrl(cfg.portalUrl);
  if (a === b) return true;
  try {
    const ua = new URL(a);
    const ub = new URL(b);
    return ua.host === ub.host && ua.pathname === ub.pathname;
  } catch (e) {
    return false;
  }
}

export function fmtTime(ts) {
  if (!ts) return '—';
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

export function fmtDuration(ms) {
  if (!ms || ms < 0) return '—';
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${h}小时${String(m).padStart(2, '0')}分${String(sec).padStart(2, '0')}秒`;
}
